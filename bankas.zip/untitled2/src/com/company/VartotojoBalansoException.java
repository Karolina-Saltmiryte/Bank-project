package com.company;

/**
 * comments
 *
 * @author egervelis
 */
public class VartotojoBalansoException extends Exception {

	private float balansas;

	public VartotojoBalansoException(String message, float balansas) {
		super(message);
		this.balansas = balansas;
	}

	public float getBalansas() {
		return balansas;
	}
}
