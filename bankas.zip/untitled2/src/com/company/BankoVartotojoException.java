package com.company;

/**
 * comments
 *
 * @author egervelis
 */
public class BankoVartotojoException extends Exception {

	private String sasNur;

	public BankoVartotojoException(String message, String sasNur) {
		super(message);
		this.sasNur = sasNur;
	}

	public String getSasNur() {
		return sasNur;
	}
}
