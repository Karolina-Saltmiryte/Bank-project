package com.company;

/**
 * comments
 *
 * @author egervelis
 */
public class BankoVartotojas {

	private String vardas;
	private String pavarde;
	private float balansas;
	private String saskaitosNumeris;


	public BankoVartotojas(String vardas, String pavarde, float balansas, String saskaitosNumeris) {
		this.vardas = vardas;
		this.pavarde = pavarde;
		this.balansas = balansas;
		this.saskaitosNumeris = saskaitosNumeris;
	}

	public String getVardas() {
		return vardas;
	}

	public String getPavarde() {
		return pavarde;
	}

	public float getBalansas() {
		return balansas;
	}

	public String getSaskaitosNumeris() {
		return saskaitosNumeris;
	}

	public void setBalansas(float balansas) {
		this.balansas = balansas;
	}

	public void pridetiPinigu(float suma) {
		balansas += suma;
	}

	public void atimtiPinigu(float suma) throws VartotojoBalansoException {

		if (balansas < suma) {
			throw new VartotojoBalansoException("Operacija negali buti ivykdyta, siunciama suma yra per didele, " +
					"atlikus operacija balansas butu neigiamas", balansas - suma);
		}
		balansas -= suma;

	}

	@Override
	public String toString() {
		return "BankoVartotojas{" +
				"vardas='" + vardas + '\'' +
				", pavarde='" + pavarde + '\'' +
				", balansas=" + balansas +
				", saskaitosNumeris='" + saskaitosNumeris + '\'' +
				'}';
	}
}
