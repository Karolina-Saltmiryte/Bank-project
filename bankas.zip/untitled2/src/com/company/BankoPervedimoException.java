package com.company;

/**
 * comments
 *
 * @author egervelis
 */
public class BankoPervedimoException extends Exception {

	private float balansas;

	public BankoPervedimoException(String message, float balansas) {
		super(message);
		this.balansas = balansas;
	}

	public float getBalansas() {
		return balansas;
	}
}
