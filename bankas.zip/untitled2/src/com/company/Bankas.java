package com.company;

import java.util.ArrayList;

/**
 * comments
 *
 * @author egervelis
 */
public class Bankas {

	private ArrayList<BankoVartotojas> visiVartotojai;

	public Bankas() {
		visiVartotojai = new ArrayList<>();
	}

	public void pridetiVartotoja(BankoVartotojas vartotojas) {
		visiVartotojai.add(vartotojas);
	}

	public void pervestiPinigus(String saskaitosNumerisSiuntejo, String saskaitosNumerisGavejo, float suma) throws BankoPervedimoException, BankoVartotojoException, VartotojoBalansoException {

		if (suma < 0) {
			throw new BankoPervedimoException("Pervedama suma negali buti neigiama", suma);
		}

		BankoVartotojas siuntejas = gautiVartotojaPagalSasNr(saskaitosNumerisSiuntejo);
		patikrinitVartotoja(siuntejas, saskaitosNumerisSiuntejo);
		BankoVartotojas gavejas = gautiVartotojaPagalSasNr(saskaitosNumerisGavejo);
		patikrinitVartotoja(gavejas, saskaitosNumerisGavejo);

		siuntejas.atimtiPinigu(suma);
		gavejas.pridetiPinigu(suma);
	}

	private void patikrinitVartotoja(BankoVartotojas vartotojas, String sasNr) throws BankoVartotojoException {
		if (vartotojas == null) {
			throw new BankoVartotojoException("Vartotojo su tokiu saskaitos numeriu nera", sasNr);
		}
	}

	private BankoVartotojas gautiVartotojaPagalSasNr(String saskaitosNumeris){
		for (BankoVartotojas vartotojas : visiVartotojai) {
			if (vartotojas.getSaskaitosNumeris().equals(saskaitosNumeris)){
				return vartotojas;
			}
		}
		return null;
	}

	public ArrayList<BankoVartotojas> getVisiVartotojai() {
		return visiVartotojai;
	}
}
