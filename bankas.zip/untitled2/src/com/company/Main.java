package com.company;


import java.util.Random;

public class Main {

	public static void main(String[] args) {

		Bankas bankas = new Bankas();

		Random rand = new Random();
		System.out.println(rand.nextInt(10));
		System.out.println(rand.nextInt(10));
		System.out.println(rand.nextInt(10));
		System.out.println(rand.nextInt(10));
		System.out.println(rand.nextInt(10));
		System.out.println(rand.nextInt(10));



		bankas.pridetiVartotoja(new BankoVartotojas("Jonas", "Jonaitis", 120, "1"));
		bankas.pridetiVartotoja(new BankoVartotojas("Petras", "Petraitis", 90, "2"));
		bankas.pridetiVartotoja(new BankoVartotojas("Edvinas", "Gervelis", 50, "3"));

		try {
			bankas.pervestiPinigus("1", "3", 50);
			spaudinti(bankas);

			bankas.pervestiPinigus("1", "8", 20);
			spaudinti(bankas);

			bankas.pervestiPinigus("1", "3", 10);
			spaudinti(bankas);

		} catch (BankoPervedimoException e) {
			System.out.println("neigiama suma" + e.getBalansas() + " negali buti pervesta, iveskite is naujo");
		} catch (BankoVartotojoException e) {
			System.out.println("Vartotojas su " + e.getSasNur() + " saskaitos numeriu neegzistuoja, pinigai nepervesti");
		} catch (VartotojoBalansoException e) {
			System.out.println(e.getMessage() + " " + e.getBalansas());
		}
	}

	private static void spaudinti(Bankas bankas) {
		for (BankoVartotojas vartotojas : bankas.getVisiVartotojai()) {
			System.out.println(vartotojas);
		}
		System.out.println("----------------------");
		System.out.println();
	}


}